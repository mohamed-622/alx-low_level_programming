#include "main.h"

/**
 * mul - a function that multiplies two integers.
 * @a: An input integer
 * @b: An input integer
 * Return: Always 0
 */
int mul(int a, int b)
{
	return (a * b);
}
