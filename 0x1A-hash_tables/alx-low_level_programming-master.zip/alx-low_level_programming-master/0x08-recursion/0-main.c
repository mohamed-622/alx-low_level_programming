#include "main.h"

/**
 * main - check the code for Holberton School students.
 *
 * Return: Always 0.
 */
int main(void)
{
  _puts_recursion("Betty Holberton");
  return (0);
}
